# Plan

Sam Solo and Pat meet on Monday.
