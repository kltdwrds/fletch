Solo Sam bundle
